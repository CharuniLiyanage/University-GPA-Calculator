function goToDashboard(){
    window.location.href = "dashboard.html";
}
